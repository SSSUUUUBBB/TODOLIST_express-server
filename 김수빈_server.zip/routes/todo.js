const express = require('express')
const Sequelize = require('sequelize');             // ✅ Sequelize 추가
const Todo = require('../models/todo')            // ✅ Board 모델 import
const router = express.Router()

router.get('/', async (req, res) => {
    let todoList = []
    try {
        todoList = await Todo.findAll()           // ✅ 전체 데이터 조회
    } catch (error) {
        console.log(error);
    }

    res.json( {todoList} )
})

router.post('/insert', async (req, res) => {
    const { name } = req.body;
    const newTodo = { name };

    let result = 0
    try {
        result = await Todo.create(newTodo)           // ✅ 데이터 등록
    } catch (error) {
        console.log(error);
    }

    console.log(`등록 result : ${result}`);
    res.json( result );
});

router.delete('/delete/:no', async (req, res) => {
    console.log('게시글 삭제...');
    const no = req.params.no;

    let result = 0
    try {
        result = await Todo.destroy({
            where: { no : no }
        })
    } catch (error) {
        console.log(error);
    }
    console.log(`삭제 result : ${result}`);

    res.json({ result, no });
});

router.delete('/deleteAll', async (req, res) => {
    try {
      result = await Todo.destroy({ where: {} });
      } catch (error) {
      console.log(error);
    }
    console.log(`삭제 result : ${result}`);

    res.json({ result });
  });

router.put('/check/:no', async (req,res) => {
    const {no, status} = req.body;

    let result = 0
    try {
        result = await Todo.update({
            status : status,
            upd_date: Sequelize.literal('now()')
        },{ where : {no: no}})
    } catch (error) {
        console.log(error);
    }
    res.json({ result, no });
});
  
router.put('/checkAll', async (req, res) => {
    const {status} = req.body
    try{
        result = await Todo.update({ status : status, upd_date: Sequelize.literal('now()')},{ where : {}});
    }catch (error) {
        console.log(error);
    }
    res.json({result})
});

module.exports = router;
  