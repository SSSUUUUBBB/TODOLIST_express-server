var express = require('express');
const Todo = require('../models/todo');
var router = express.Router();

// GET / 라우터
router.get('/', (req, res) => {
  res.render('index', { title: 'Main' });
});

module.exports = router;