import React from 'react'

const TodoFooter = ({deleteAll, checkAll}) => {
  return (
    <div className='footer' style={{display:'flex', justifyContent:'space-between', margin:'10px 10px 10px 0'}}>
        <button className='btn' onClick={deleteAll}>전체삭제</button>
        <button className='btn' onClick={checkAll}>전체완료</button>
    </div>
  )
}

export default TodoFooter