import React from 'react'

const TodoHeader = () => {
  return (
    <div style={{textAlign:'center', fontSize:'20px', color:'violet'}}>
      <h1>To Do List</h1>
    </div>
  )
}

export default TodoHeader