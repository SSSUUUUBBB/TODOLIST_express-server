import React, { useEffect, useState } from 'react'
import TodoHeader from './TodoHeader'
import TodoInput from './TodoInput'
import TodoList from './TodoList'
import TodoFooter from './TodoFooter'

const TodoContainer = () => {
  const [Todo, setTodo] = useState([]);
  const [input, setInput] = useState('');

  useEffect(() => {
    fetch('http://localhost:8080/todo')
      .then((response) => response.json())
      .then((data) => {
        const list = data.todoList
        const sortedTodo = Array.isArray(list)
          ? list.sort((a, b) => {
            return a.status - b.status == 0 ? b.no - a.no : a.status - b.status
          }):[];
        setTodo(sortedTodo);
        })
      .catch((error) => console.error('Fetch error:', error));
  }, []);

  const onChange = (e) => {
    setInput(e.target.value);
  };

  const insert = async (e) =>{
    e.preventDefault();
    if( input == '' ) {
      input = '제목없음'
    }
    const data = {name : input}
    const init = {
      method : 'POST',
      headers : {
        'Content-Type' : 'application/json'
      },
      body : JSON.stringify(data)
    }
    try {
      const response = await fetch('http://localhost:8080/todo/insert', init);
      const newTodo = await response.json();
      const updatedList = [newTodo, ...Todo]
      setTodo( updatedList );
    } catch (error) {
      console.log(error);
    }
    setInput('');
  }

  const tododelete = async (no) =>{
    const init = {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
    };

    try {
      const response = await fetch(`http://localhost:8080/todo/delete/${no}`, init);
      console.log(response);
    } catch (error) {
      console.log(error);
    }

    setTodo( (Todo) => Todo.filter((todo) => todo.no !== no) )

  }

  const deleteAll = async () =>{
    const init = {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      }
    };

    try {
      const response = await fetch(`http://localhost:8080/todo/deleteAll`, init);
      console.log(response);
    } catch (error) {
      console.log(error);
    }
    setTodo([])
  }

  const check = async (todo) => {
    const data = {
      no : todo.no,
      status : todo.status ? 0 : 1
    };
    const init = {
      method : 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data)
    }

    try {
      const response = await fetch(`http://localhost:8080/todo/check/${todo.no}`, init)
    } catch (error) {
      console.log(error);
    }

    setTodo((Todo) => {
      return Todo.map((item) => {
        return item.no === todo.no ? { ...item, status: !item.status} : item; 
      }).sort((a, b) => {
        return a.status - b.status == 0 ? b.no - a.no : a.status - b.status;
      });
    });
  }

  const checkAll = async (todo) => {
    const data = {
      no : todo.no,
      status : 1
    };
    const init = {
      method : 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data)
    }

    try {
      const response = await fetch(`http://localhost:8080/todo/checkAll`, init)
    } catch (error) {
      console.log(error);
    }

    setTodo((Todo) => {
      return Todo.map((item) => {
        return { ...item, status: true}; 
      }).sort((a, b) => {
        return a.status - b.status == 0 ? b.no - a.no : a.status - b.status;
      });
    });
  }

  return (
    <div className="container">
    <TodoHeader />
    <TodoInput insert={insert} onChange={onChange} />
    <TodoList Todo={Todo} tododelete={tododelete} check={check} />
    <TodoFooter deleteAll={deleteAll} checkAll={checkAll} />
    </div>
  )
}

export default TodoContainer