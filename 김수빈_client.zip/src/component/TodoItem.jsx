import React from 'react'

const TodoItem = ({todo, tododelete, check}) => {
  const {no, name, status} = todo;
  const checked = status == 1 ? true : false;
  const className = checked ? 'todoItem active' : 'todoItem';

  return (
    <li className={className}>
      <div className="item">
        <input type="checkbox" checked={checked} onChange={() => check(todo)} name="todo" id={no} />
        <label htmlFor={no}></label> {/* htmlFor : input과 label 연결 시켜줌 */}
        <span className='content'>{name}</span>
      </div>
      <div className="item">
        <button className='btn' onClick={() => tododelete(no)}>삭제</button>
      </div>
    </li>
  )

}

export default TodoItem;