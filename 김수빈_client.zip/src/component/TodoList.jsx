import React, { useEffect, useState } from 'react';
import TodoItem from './TodoItem';

const TodoList = ({Todo, tododelete, check}) => {
    return (
      <ul className='todoList' style={{height:'500px', overflowY:'auto', margin:'0', padding:'0'}}>
        {Todo.map((content) => (
          <>
          <TodoItem todo={content} key={content.no} tododelete={tododelete} check={check} />
          </>
        ))}
      </ul>
    );
}

export default TodoList