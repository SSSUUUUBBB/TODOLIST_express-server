import React, { useState } from 'react'

const TodoInput = ({input, insert, onChange}) => {
  return (
    <div >
      <form onSubmit={insert} className='form'>
        <input placeholder='할 일 입력' onChange={onChange} className='input' type="text" id='input' name='input' value={input}/>
        <button type='submit' className='btn' >추가</button>
      </form>
    </div>
  )
}

export default TodoInput