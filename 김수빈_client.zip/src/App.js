import './App.css';
import TodoContainer from './component/TodoContainer';

function App() {
  return (
    <TodoContainer />
  );
}

export default App;
